# Yandex offline conversion module

## Как это работает

* Модуль отправляет обязательный `pageview`, а затем простые события `event`
  с `ea=trial-add` или `ea=purchase`. Ecom-параметры (`pa`, `pr*`, `ti`, `tr`,
  `tcc`) не используются\*.
* Перед каждым событием принудительно отправляется `pageview`, чтобы
  инициализировать визит Measurement Protocol.
* `cid` хранится в базе и маскируется в логах. Если `cid` не найден или не
  валиден, запросы к MP не выполняются.
* Отправка выполняется через HTTP POST на `https://mc.yandex.ru/collect` с
  ретраями и таймаутами из настроек модуля.
* Опционально можно включить передачу `dl` и для событий, установив
  `YA_EVENT_INCLUDE_DL=true` (актуально, если в счётчике включено требование к
  источнику адреса).

\* Если понадобится ecom-отчётность, её придётся реализовывать отдельно — этот
модуль работает только с простыми целями.

### Примеры запросов

```text
POST https://mc.yandex.ru/collect
t=pageview&tid=<YA_TID>&cid=<CID>&ms=<YA_MS>&dl=<YA_DL>&dr=<YA_DR>&dt=<YA_DT>

t=event&tid=<YA_TID>&cid=<CID>&ms=<YA_MS>&ea=trial-add

t=event&tid=<YA_TID>&cid=<CID>&ms=<YA_MS>&ea=purchase
```

`<CID>` заменяется на фактический `cid` пользователя; дополнительные параметры
`et` можно добавлять при необходимости.

## Что модуль получает из БД

* сохранённый `cid`, привязанный к `tg_user_id` пользователя.
* `order_id` пока не используется при отправке событий, но остаётся в сигнатуре
  метода `send_purchase` на будущее.

## API/Протокол

* URL: `https://mc.yandex.ru/collect`.
* Метод: `POST` (допустим `GET`). Формат: пары `key=value` в UTF-8.
* Обязательные параметры для `pageview`: `t=pageview`, `tid`, `cid`, `ms`,
  `dl`, `dr`, `dt`.
* Обязательные параметры для `event`: `t=event`, `tid`, `cid`, `ms`, `ea`
  (и опциональный `et`).
* Если у `cid` нет активного визита, модуль всегда отправляет `pageview`, а
  затем событие.
* Событие должно быть не старше 12 часов — иначе стоит отправлять онлайн.

## Subscription link enrichment hook

The module registers the `subscription_link_enrich` hook that is triggered when
Remnawave device connection links are prepared. The hook looks up a previously
captured `yclid` for the current Telegram user and, when it is present and
valid, appends it to the link as a query parameter.

### Behaviour

* If a valid `yclid` is stored for the user, the resulting URL contains
  `?yclid=<value>` (or `&yclid=` when the query string already exists).
* Existing query parameters and URL fragments are preserved. When the URL
  already has a `yclid` parameter its value is kept unchanged.
* When no `yclid` is stored (the user did not start the bot from a Yandex ads
  link) the URL is returned untouched.

### Requirements

For the enrichment to work the user must previously start the bot with a
`utm_ya_*` deep link so that the module can persist the click identifier in the
`yandex_yclid_map` table. No additional configuration is required.
