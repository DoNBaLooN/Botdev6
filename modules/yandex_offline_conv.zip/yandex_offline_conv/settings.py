"""Settings for the Yandex offline conversions module."""

from __future__ import annotations

from decimal import Decimal


# Toggle the module on/off. When disabled, hooks keep persisting metadata but
# the periodic background task will not run.
ENABLED: bool = True

# Opt-in flag for the legacy CSV/yclid pipeline. The Measurement Protocol flow
# is enabled regardless of this flag. Keep ``False`` by default to avoid
# running outdated jobs.
ENABLED_LEGACY: bool = False

# Credentials for the legacy Yandex Offline Conversions API (unused when
# ``ENABLED_LEGACY`` is ``False``).
COUNTER_ID: str | None = None
OAUTH_TOKEN: str | None = None

# Conversion settings.
GOAL_NAME: str = "trial_taken"
CURRENCY: str = "RUB"
VALUE: Decimal = Decimal("0")

# Scheduling and retry behaviour.
POLL_INTERVAL_SECONDS: int = 60
MAX_RETRIES: int = 5
RETRY_INTERVAL_SECONDS: int = 900
HTTP_TIMEOUT_SECONDS: int = 15
QUEUE_BATCH_SIZE: int = 20

# Recognised prefix for /start deep-links.
START_PREFIX: str = "utm_ya_"

# Allow initial backfill of historic events for existing users.
ALLOW_INITIAL_BACKFILL: bool = False

# Extra payload can be extended through this hook if required in future.
EXTRA_PAYLOAD_TEMPLATE: dict[str, str] = {}


# --- Measurement Protocol configuration ---

# Yandex.Metrica counter ID used for Measurement Protocol requests.
YA_TID = "105003582"

# Measurement Protocol secret token (do not log this value).
YA_MS = "9f2b6831-2851-4c88-b677-a8027c435260"

# Base collection endpoint.
YA_COLLECT_URL: str = "https://mc.yandex.ru/collect"

# Default pageview parameters that "warm up" a visit before sending events.
YA_DL: str = "https://t.me/WBVLess_bot?start=mp"
YA_DR: str = "https://yandex.ru"
YA_DT: str = "Telegram Bot"

# When ``True`` the module also attaches ``dl`` to ``event`` hits. Enable this if
# the counter is configured to accept data only from specific domains.
YA_EVENT_INCLUDE_DL: bool = False

# Behaviour of the lightweight HTTP client used for the Measurement Protocol.
YA_TIMEOUT_SECONDS: float = 10.0
YA_MAX_ATTEMPTS: int = 3
YA_RETRY_DELAY_SECONDS: float = 1.0
