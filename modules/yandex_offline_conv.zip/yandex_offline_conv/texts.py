"""Text constants for the Yandex offline conversion module."""

LOG_PREFIX = "[YandexOfflineConv]"
