"""Database helpers for the Yandex offline conversion module."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import Select

from database.models import Tariff, User

from .models import YandexClientIdMap


async def upsert_cid(session: AsyncSession, tg_id: int, cid: str) -> None:
    """Store or update the Measurement Protocol client ID for a user."""

    stmt = (
        insert(YandexClientIdMap)
        .values(tg_id=tg_id, cid=cid, created_at=datetime.utcnow())
        .on_conflict_do_update(
            index_elements=[YandexClientIdMap.tg_id],
            set_={
                "cid": cid,
                "updated_at": datetime.utcnow(),
            },
        )
    )
    await session.execute(stmt)


async def get_cid(session: AsyncSession, tg_id: int) -> str | None:
    """Return the stored Measurement Protocol client ID for a user."""

    stmt: Select = select(YandexClientIdMap.cid).where(YandexClientIdMap.tg_id == tg_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def get_trial_status(session: AsyncSession, tg_id: int) -> int | None:
    """Return the current trial status for diagnostics/instrumentation."""

    stmt: Select = select(User.trial).where(User.tg_id == tg_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def get_tariff_snapshot(session: AsyncSession | None, tariff_id: Any) -> dict[str, Any] | None:
    """Return a lightweight snapshot of a tariff for diagnostic purposes."""

    if session is None or not isinstance(session, AsyncSession):
        return None

    try:
        numeric_id = int(tariff_id)
    except (TypeError, ValueError):
        return None

    stmt: Select = select(Tariff).where(Tariff.id == numeric_id)
    result = await session.execute(stmt)
    tariff = result.scalar_one_or_none()
    if tariff is None:
        return None

    snapshot: dict[str, Any] = {
        "id": tariff.id,
        "name": tariff.name,
        "price_rub": tariff.price_rub,
        "duration_days": tariff.duration_days,
    }

    for attr in ("is_trial", "trial_days", "trial", "trial_enabled"):
        value = getattr(tariff, attr, None)
        if value is not None:
            snapshot[attr] = value

    return snapshot
