"""Database models for the Yandex offline conversion module."""

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB

from database.models import Base


class YandexClientIdMap(Base):
    """Maps Telegram user IDs to Measurement Protocol client IDs (cid)."""

    __tablename__ = "yandex_client_id_map"

    tg_id = Column(BigInteger, primary_key=True)
    cid = Column(String(128), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )


class YandexYclidMap(Base):  # pragma: no cover - legacy support
    """Legacy mapping of Telegram user IDs to Yandex click identifiers (yclid)."""

    __tablename__ = "yandex_yclid_map"

    tg_id = Column(BigInteger, primary_key=True)
    yclid = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )


class YandexTrialEvent(Base):
    """Represents the moment when a user receives a trial subscription."""

    __tablename__ = "yandex_trial_events"
    __table_args__ = (UniqueConstraint("tg_id", name="uq_yandex_trial_events_tg_id"),)

    id = Column(Integer, primary_key=True, autoincrement=True)
    tg_id = Column(BigInteger, nullable=False)
    status = Column(String, nullable=False, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    queued_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)


class YandexConversionQueue(Base):
    """Queue of offline conversions waiting to be sent to Yandex Metrica."""

    __tablename__ = "yandex_offline_conv_queue"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(
        Integer,
        ForeignKey("yandex_trial_events.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    tg_id = Column(BigInteger, nullable=False)
    yclid = Column(String, nullable=False)
    goal_name = Column(String, nullable=False)
    event_time = Column(DateTime, nullable=False)
    amount_value = Column(Numeric(12, 2), nullable=False, default=0)
    currency = Column(String, nullable=False, default="RUB")
    attempts = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=3)
    status = Column(String, nullable=False, default="pending")
    last_error = Column(Text, nullable=True)
    next_attempt_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )
    sent_at = Column(DateTime, nullable=True)
    extra_payload = Column(JSONB, nullable=True)
