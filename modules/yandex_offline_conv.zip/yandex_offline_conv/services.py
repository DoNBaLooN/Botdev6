"""Core business logic for the Yandex offline conversion module."""

from __future__ import annotations

import asyncio
import functools
import inspect
import re
import sys
import time
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable, Tuple

import requests
from requests import Response
from requests.exceptions import RequestException

from logger import logger
from sqlalchemy.ext.asyncio import AsyncSession

from . import db, settings, texts


@dataclass(slots=True)
class SendResult:
    """Result of a Measurement Protocol send attempt."""

    success: bool
    status_code: int | None
    message: str

    def __bool__(self) -> bool:  # pragma: no cover - convenience
        return self.success


_CID_PATTERN = re.compile(r"^[A-Za-z0-9._-]{6,64}$")
_PREFIX_STRIP_CHARS = "_=:-"


def _normalize_cid(cid: str | None) -> str | None:
    if not isinstance(cid, str):
        return None
    trimmed = cid.strip()
    return trimmed or None


def _mask_cid(cid: str | None) -> str:
    if not cid:
        return "<empty>"
    visible = cid[-4:]
    masked_prefix = "*" * max(0, len(cid) - len(visible))
    return f"{masked_prefix}{visible}" if masked_prefix else visible


def mask_cid(cid: str | None) -> str:
    """Expose masked cid for logging outside this module."""

    return _mask_cid(cid)


_PATCH_FLAG_ATTR = "__yandex_offline_conv_patched__"
_INSTRUMENTATION_INSTALLED = False


def _replace_function_references(original: Callable[..., Any], replacement: Callable[..., Any]) -> int:
    """Replace occurrences of ``original`` in already-imported modules."""

    replaced = 0
    for module in list(sys.modules.values()):
        module_dict = getattr(module, "__dict__", None)
        if not module_dict:
            continue
        for attr, value in list(module_dict.items()):
            if value is original:
                try:
                    setattr(module, attr, replacement)
                    replaced += 1
                except Exception:  # pragma: no cover - defensive logging
                    logger.exception(
                        "%s Failed to replace reference %s.%s during instrumentation",
                        texts.LOG_PREFIX,
                        getattr(module, "__name__", module),
                        attr,
                    )
    return replaced


def _summarize_argument(name: str, value: Any) -> Any:
    if name == "session" and value is not None:
        return f"<{type(value).__name__}>"
    if name in {"message", "callback", "callback_query", "state"} and value is not None:
        return f"<{type(value).__name__}>"
    if isinstance(value, dict):
        preview = {k: value[k] for k in list(value.keys())[:5]}
        if len(value) > len(preview):
            preview["..."] = f"+{len(value) - len(preview)} keys"
        return preview
    return value


def _sanitize_arguments(arguments: inspect.BoundArguments) -> dict[str, Any]:
    return {name: _summarize_argument(name, value) for name, value in arguments.arguments.items()}


def _extract_plan_id(plan: Any) -> int | None:
    candidate = None
    if isinstance(plan, (int, str)):
        candidate = plan
    elif isinstance(plan, dict):
        candidate = plan.get("id") or plan.get("tariff_id")
    else:
        for attr in ("id", "tariff_id", "plan_id"):
            if hasattr(plan, attr):
                candidate = getattr(plan, attr)
                if candidate is not None:
                    break
    if candidate is None:
        return None
    try:
        return int(candidate)
    except (TypeError, ValueError):
        return None


def _collect_plan_flags(plan: Any) -> dict[str, Any]:
    if plan is None:
        return {}

    getter = None
    if isinstance(plan, dict):
        getter = plan.get
    else:
        getter = lambda key: getattr(plan, key, None)

    flags: dict[str, Any] = {}

    is_trial_value = getter("is_trial")
    if is_trial_value is None:
        is_trial_value = getter("trial")
    if is_trial_value is not None:
        flags["is_trial"] = bool(is_trial_value)

    trial_days = getter("trial_days")
    if trial_days:
        flags["trial_days"] = trial_days

    duration_days = getter("duration_days")
    if duration_days:
        flags["duration_days"] = duration_days

    price = getter("price_rub")
    if price is not None:
        try:
            price_decimal = Decimal(str(price))
        except Exception:  # pragma: no cover - diagnostic only
            flags["price_rub"] = price
        else:
            flags["price_rub"] = str(price_decimal)
            if price_decimal == 0:
                flags["zero_price"] = True

    name = getter("name")
    if isinstance(name, str) and name:
        flags["name_contains_trial"] = "trial" in name.lower() or "триал" in name.lower()

    return flags


def _coerce_truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value in (None, "", 0):
        return False
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


async def _evaluate_trial_condition(bound: inspect.BoundArguments) -> tuple[bool, dict[str, Any]]:
    session = bound.arguments.get("session")
    plan_argument = bound.arguments.get("plan")
    plan_snapshot = None
    plan_flags = _collect_plan_flags(plan_argument)
    plan_id = _extract_plan_id(plan_argument)

    if plan_snapshot is None and plan_id is not None:
        try:
            plan_snapshot = await db.get_tariff_snapshot(session, plan_id)
        except Exception:
            logger.exception(
                "%s Failed to fetch tariff snapshot for plan_id=%s", texts.LOG_PREFIX, plan_id
            )
        else:
            if plan_snapshot:
                plan_flags = _collect_plan_flags(plan_snapshot)

    hints: list[str] = []
    raw_is_trial = bound.arguments.get("is_trial")
    if _coerce_truthy(raw_is_trial):
        hints.append("arg:is_trial")
    if plan_flags.get("is_trial"):
        hints.append("plan:is_trial")
    trial_days = plan_flags.get("trial_days")
    if trial_days:
        hints.append(f"plan:trial_days={trial_days}")
    if plan_flags.get("zero_price"):
        hints.append("plan:zero_price")
    if plan_flags.get("name_contains_trial"):
        hints.append("plan:name_contains_trial")

    debug_payload = {
        "hints": hints,
        "plan_id": plan_id,
        "plan_flags": plan_flags,
        "plan_snapshot": plan_snapshot,
        "raw_is_trial": raw_is_trial,
    }
    return bool(hints), debug_payload


async def _dispatch_send(func: Callable[..., SendResult], *args, **kwargs) -> SendResult:
    """Run blocking Measurement Protocol calls in a thread pool."""

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return func(*args, **kwargs)

    return await loop.run_in_executor(None, functools.partial(func, *args, **kwargs))


async def _handle_trial_event(
    session: AsyncSession | None,
    tg_id: Any,
    *,
    plan: Any = None,
    context: str = "",
) -> None:
    if session is None or not isinstance(session, AsyncSession):
        logger.debug(
            "%s Skipping trial tracking (no session) for tg_id=%s context=%s",
            texts.LOG_PREFIX,
            tg_id,
            context,
        )
        return

    try:
        numeric_tg_id = int(tg_id)
    except (TypeError, ValueError):
        logger.warning(
            "%s Skipping trial tracking due to invalid tg_id=%r context=%s",
            texts.LOG_PREFIX,
            tg_id,
            context,
        )
        return

    try:
        cid = await db.get_cid(session, numeric_tg_id)
    except Exception:
        logger.exception(
            "%s Failed to look up cid for trial event (tg_id=%s context=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
        )
        return

    if not cid:
        logger.debug(
            "%s No cid stored for trial event (tg_id=%s context=%s plan=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
            plan,
        )
        return

    try:
        result = await _dispatch_send(send_trial_add, cid)
    except Exception:
        logger.exception(
            "%s Unexpected error while sending trial event (tg_id=%s context=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
        )
        return

    masked_cid = mask_cid(cid)
    if result.success:
        logger.info(
            "%s Trial event sent (tg_id=%s cid=%s context=%s plan=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            masked_cid,
            context or "unknown",
            plan,
        )
    else:
        logger.warning(
            "%s Trial event failed (tg_id=%s cid=%s context=%s plan=%s status=%s message=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            masked_cid,
            context or "unknown",
            plan,
            result.status_code,
            result.message,
        )


async def _handle_purchase_event(
    session: AsyncSession | None,
    tg_id: Any,
    *,
    amount: Any = None,
    payment_system: Any = None,
    context: str = "",
) -> None:
    if session is None or not isinstance(session, AsyncSession):
        logger.debug(
            "%s Skipping purchase tracking (no session) for tg_id=%s context=%s",
            texts.LOG_PREFIX,
            tg_id,
            context,
        )
        return

    try:
        numeric_tg_id = int(tg_id)
    except (TypeError, ValueError):
        logger.warning(
            "%s Skipping purchase tracking due to invalid tg_id=%r context=%s",
            texts.LOG_PREFIX,
            tg_id,
            context,
        )
        return

    try:
        cid = await db.get_cid(session, numeric_tg_id)
    except Exception:
        logger.exception(
            "%s Failed to look up cid for purchase event (tg_id=%s context=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
        )
        return

    if not cid:
        logger.debug(
            "%s No cid stored for purchase event (tg_id=%s context=%s amount=%s system=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
            amount,
            payment_system,
        )
        return

    try:
        result = await _dispatch_send(send_purchase, cid)
    except Exception:
        logger.exception(
            "%s Unexpected error while sending purchase event (tg_id=%s context=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            context,
        )
        return

    masked_cid = mask_cid(cid)
    if result.success:
        logger.info(
            "%s Purchase event sent (tg_id=%s cid=%s context=%s amount=%s system=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            masked_cid,
            context or "unknown",
            amount,
            payment_system,
        )
    else:
        logger.warning(
            "%s Purchase event failed (tg_id=%s cid=%s context=%s amount=%s system=%s status=%s message=%s)",
            texts.LOG_PREFIX,
            numeric_tg_id,
            masked_cid,
            context or "unknown",
            amount,
            payment_system,
            result.status_code,
            result.message,
        )


def _instrument_create_key_on_cluster() -> None:
    try:
        from handlers.keys.operations import creation as key_creation
    except Exception as exc:
        logger.warning(
            "%s Unable to import key creation module for instrumentation: %s",
            texts.LOG_PREFIX,
            exc,
        )
        return

    original = getattr(key_creation, "create_key_on_cluster", None)
    if original is None or getattr(original, _PATCH_FLAG_ATTR, False):
        return

    signature = inspect.signature(original)

    @functools.wraps(original)
    async def wrapped(*args, **kwargs):
        try:
            bound = signature.bind_partial(*args, **kwargs)
        except TypeError:
            logger.exception(
                "%s Failed to bind arguments for create_key_on_cluster instrumentation",
                texts.LOG_PREFIX,
            )
            return await original(*args, **kwargs)

        logger.debug(
            "%s create_key_on_cluster instrumentation entry tg_id=%s named=%s",
            texts.LOG_PREFIX,
            bound.arguments.get("tg_id"),
            _sanitize_arguments(bound),
        )

        result = await original(*args, **kwargs)

        try:
            should_track, debug_payload = await _evaluate_trial_condition(bound)
        except Exception:
            logger.exception(
                "%s Failed to evaluate trial condition (tg_id=%s)",
                texts.LOG_PREFIX,
                bound.arguments.get("tg_id"),
            )
            return result

        debug_context = dict(debug_payload)
        if "plan_snapshot" in debug_context and debug_context["plan_snapshot"] is not None:
            debug_context["plan_snapshot"] = _summarize_argument("plan", debug_context["plan_snapshot"])

        logger.debug(
            "%s create_key_on_cluster instrumentation decision tg_id=%s track=%s details=%s",
            texts.LOG_PREFIX,
            bound.arguments.get("tg_id"),
            should_track,
            debug_context,
        )

        if should_track:
            session = bound.arguments.get("session")
            tg_id = bound.arguments.get("tg_id")
            plan = debug_payload.get("plan_snapshot") or bound.arguments.get("plan")
            try:
                await _handle_trial_event(
                    session,
                    tg_id,
                    plan=plan,
                    context="create_key_on_cluster",
                )
            except Exception:
                logger.exception(
                    "%s Trial tracking handler raised (tg_id=%s context=create_key_on_cluster)",
                    texts.LOG_PREFIX,
                    bound.arguments.get("tg_id"),
                )

        return result

    setattr(original, _PATCH_FLAG_ATTR, True)
    setattr(wrapped, _PATCH_FLAG_ATTR, True)
    key_creation.create_key_on_cluster = wrapped
    replaced = _replace_function_references(original, wrapped)
    if replaced:
        logger.debug(
            "%s create_key_on_cluster references updated in %s locations",
            texts.LOG_PREFIX,
            replaced,
        )
    logger.info("%s Instrumented create_key_on_cluster for trial tracking", texts.LOG_PREFIX)


def _instrument_add_payment() -> None:
    try:
        from database import payments as payments_module
        import database as database_pkg
    except Exception as exc:
        logger.warning(
            "%s Unable to import payments module for instrumentation: %s",
            texts.LOG_PREFIX,
            exc,
        )
        return

    original = getattr(payments_module, "add_payment", None)
    if original is None or getattr(original, _PATCH_FLAG_ATTR, False):
        return

    signature = inspect.signature(original)

    @functools.wraps(original)
    async def wrapped(*args, **kwargs):
        try:
            bound = signature.bind_partial(*args, **kwargs)
        except TypeError:
            logger.exception(
                "%s Failed to bind arguments for add_payment instrumentation",
                texts.LOG_PREFIX,
            )
            return await original(*args, **kwargs)

        logger.debug(
            "%s add_payment instrumentation entry tg_id=%s named=%s",
            texts.LOG_PREFIX,
            bound.arguments.get("tg_id"),
            _sanitize_arguments(bound),
        )

        result = await original(*args, **kwargs)

        session = bound.arguments.get("session")
        tg_id = bound.arguments.get("tg_id")
        amount = bound.arguments.get("amount")
        payment_system = bound.arguments.get("payment_system")

        try:
            await _handle_purchase_event(
                session,
                tg_id,
                amount=amount,
                payment_system=payment_system,
                context="add_payment",
            )
        except Exception:
            logger.exception(
                "%s Purchase tracking handler raised (tg_id=%s context=add_payment)",
                texts.LOG_PREFIX,
                tg_id,
            )

        return result

    setattr(original, _PATCH_FLAG_ATTR, True)
    setattr(wrapped, _PATCH_FLAG_ATTR, True)
    payments_module.add_payment = wrapped
    if getattr(database_pkg, "add_payment", None) is original:
        database_pkg.add_payment = wrapped
    replaced = _replace_function_references(original, wrapped)
    if replaced:
        logger.debug(
            "%s add_payment references updated in %s locations",
            texts.LOG_PREFIX,
            replaced,
        )
    logger.info("%s Instrumented add_payment for purchase tracking", texts.LOG_PREFIX)


def _instrument_update_trial() -> None:
    try:
        from database import users as users_module
        import database as database_pkg
    except Exception as exc:
        logger.warning(
            "%s Unable to import users module for instrumentation: %s",
            texts.LOG_PREFIX,
            exc,
        )
        return

    original = getattr(users_module, "update_trial", None)
    if original is None or getattr(original, _PATCH_FLAG_ATTR, False):
        return

    signature = inspect.signature(original)

    @functools.wraps(original)
    async def wrapped(*args, **kwargs):
        try:
            bound = signature.bind_partial(*args, **kwargs)
        except TypeError:
            logger.exception(
                "%s Failed to bind arguments for update_trial instrumentation",
                texts.LOG_PREFIX,
            )
            return await original(*args, **kwargs)

        logger.debug(
            "%s update_trial instrumentation entry tg_id=%s named=%s",
            texts.LOG_PREFIX,
            bound.arguments.get("tg_id"),
            _sanitize_arguments(bound),
        )

        should_track = False
        session = bound.arguments.get("session")
        tg_id = bound.arguments.get("tg_id")
        status = bound.arguments.get("status")
        numeric_tg_id: int | None = None

        if status == 1:
            try:
                numeric_tg_id = int(tg_id)
            except (TypeError, ValueError):
                logger.debug(
                    "%s update_trial instrumentation skipping invalid tg_id=%r",
                    texts.LOG_PREFIX,
                    tg_id,
                )
            else:
                if isinstance(session, AsyncSession):
                    try:
                        previous_status = await db.get_trial_status(session, numeric_tg_id)
                    except Exception:
                        logger.exception(
                            "%s Failed to read previous trial status (tg_id=%s)",
                            texts.LOG_PREFIX,
                            numeric_tg_id,
                        )
                        should_track = True
                    else:
                        should_track = previous_status != 1
                else:
                    should_track = True

        result = await original(*args, **kwargs)

        if should_track and status == 1:
            try:
                await _handle_trial_event(
                    session,
                    tg_id,
                    context="update_trial",
                )
            except Exception:
                logger.exception(
                    "%s Trial tracking handler raised (tg_id=%s context=update_trial)",
                    texts.LOG_PREFIX,
                    tg_id,
                )

        return result

    setattr(original, _PATCH_FLAG_ATTR, True)
    setattr(wrapped, _PATCH_FLAG_ATTR, True)
    users_module.update_trial = wrapped
    if getattr(database_pkg, "update_trial", None) is original:
        database_pkg.update_trial = wrapped
    replaced = _replace_function_references(original, wrapped)
    if replaced:
        logger.debug(
            "%s update_trial references updated in %s locations",
            texts.LOG_PREFIX,
            replaced,
        )
    logger.info("%s Instrumented update_trial for trial tracking", texts.LOG_PREFIX)


def install_instrumentation() -> None:
    global _INSTRUMENTATION_INSTALLED
    if _INSTRUMENTATION_INSTALLED:
        return

    _instrument_create_key_on_cluster()
    _instrument_add_payment()
    _instrument_update_trial()
    _INSTRUMENTATION_INSTALLED = True

def extract_cid(part: str) -> Tuple[str | None, str | None]:
    """Extract ``cid`` value from a Telegram ``/start`` parameter part."""

    if not part or not isinstance(part, str):
        return None, None

    prefix = settings.START_PREFIX or ""
    trimmed_part = part.strip()
    if not trimmed_part:
        return None, None

    prefix_lower = prefix.lower()
    trimmed_lower = trimmed_part.lower()
    base_prefix = prefix_lower.rstrip(_PREFIX_STRIP_CHARS) if prefix_lower else ""

    remainder: str | None = None
    remainder_start = 0
    if prefix and trimmed_lower.startswith(prefix_lower):
        suffix = trimmed_part[len(prefix) :]
        stripped_suffix = suffix.lstrip(_PREFIX_STRIP_CHARS)
        remainder_start = len(trimmed_part) - len(stripped_suffix)
        remainder = stripped_suffix
    elif base_prefix and trimmed_lower == base_prefix:
        cleaned_part = trimmed_part.rstrip(_PREFIX_STRIP_CHARS) or trimmed_part
        return None, cleaned_part
    else:
        return None, None

    if remainder is None:
        return None, None

    for separator in ("?", "&", "#"):
        if separator in remainder:
            remainder = remainder.split(separator, 1)[0]
            break

    candidate = remainder.strip(_PREFIX_STRIP_CHARS)
    cleaned_part = trimmed_part
    if candidate:
        idx = trimmed_part.find(candidate, remainder_start)
        if idx != -1:
            cleaned_part = trimmed_part[:idx]
    cleaned_part = cleaned_part.rstrip(_PREFIX_STRIP_CHARS) or None

    if candidate and _CID_PATTERN.fullmatch(candidate):
        return candidate, cleaned_part

    return None, cleaned_part


def is_valid_cid(value: str | None) -> bool:
    """Return ``True`` when ``value`` looks like a valid client identifier."""

    if not value or not isinstance(value, str):
        return False
    return bool(_CID_PATTERN.fullmatch(value.strip()))


async def store_cid(
    session,
    tg_id: int,
    cid: str,
    *,
    start_part: str | None = None,
    cleaned_part: str | None = None,
) -> None:
    """Persist ``cid`` mapping for a Telegram user."""

    logger.debug(
        "%s Storing cid=%s for tg_id=%s (start_part=%r, cleaned_part=%r)",
        texts.LOG_PREFIX,
        _mask_cid(cid),
        tg_id,
        start_part,
        cleaned_part,
    )
    await db.upsert_cid(session, tg_id, cid)


def _prepare_common_payload(cid: str) -> tuple[str, dict[str, str]] | SendResult:
    normalized = _normalize_cid(cid)
    if not normalized:
        message = "ClientID (cid) must be a non-empty string"
        logger.warning("%s %s", texts.LOG_PREFIX, message)
        return SendResult(False, None, message)

    if not settings.YA_TID or not settings.YA_MS:
        message = "Measurement Protocol credentials are not configured"
        logger.error(
            "%s Measurement Protocol configuration missing (cid=%s)",
            texts.LOG_PREFIX,
            _mask_cid(normalized),
        )
        return SendResult(False, None, message)

    base_payload = {
        "tid": str(settings.YA_TID),
        "cid": normalized,
        "ms": str(settings.YA_MS),
    }
    return normalized, base_payload


def _collect_url() -> str:
    return settings.YA_COLLECT_URL or "https://mc.yandex.ru/collect"


def _send_with_retry(kind: str, payload: dict[str, str], cid: str) -> SendResult:
    url = _collect_url()
    masked_cid = _mask_cid(cid)
    timeout = settings.YA_TIMEOUT_SECONDS
    max_attempts = max(1, settings.YA_MAX_ATTEMPTS)
    delay = max(0.0, settings.YA_RETRY_DELAY_SECONDS)

    last_message = ""
    for attempt in range(1, max_attempts + 1):
        try:
            response: Response = requests.post(url, data=payload, timeout=timeout)
        except RequestException as exc:  # network error
            last_message = str(exc)
            logger.warning(
                "%s MP %s request error (attempt %s/%s, cid=%s): %s",
                texts.LOG_PREFIX,
                kind,
                attempt,
                max_attempts,
                masked_cid,
                last_message,
            )
            if attempt == max_attempts:
                return SendResult(False, None, last_message)
            if delay:
                time.sleep(delay)
            continue

        status = response.status_code
        body = response.text
        if 200 <= status < 300:
            logger.info(
                "%s MP %s delivered (cid=%s, status=%s)",
                texts.LOG_PREFIX,
                kind,
                masked_cid,
                status,
            )
            return SendResult(True, status, "ok")

        last_message = f"status={status} body={body}"
        if 500 <= status < 600:
            logger.warning(
                "%s MP %s server error (attempt %s/%s, cid=%s, status=%s)",
                texts.LOG_PREFIX,
                kind,
                attempt,
                max_attempts,
                masked_cid,
                status,
            )
            if attempt == max_attempts:
                return SendResult(False, status, last_message)
            if delay:
                time.sleep(delay)
            continue

        logger.error(
            "%s MP %s rejected (cid=%s, status=%s)",
            texts.LOG_PREFIX,
            kind,
            masked_cid,
            status,
        )
        return SendResult(False, status, last_message)

    return SendResult(False, None, last_message or "unknown error")


def _pageview_payload(base_payload: dict[str, str]) -> dict[str, str]:
    payload = dict(base_payload)
    payload.update(
        {
            "t": "pageview",
            "dl": settings.YA_DL,
            "dr": settings.YA_DR,
            "dt": settings.YA_DT,
        }
    )
    return payload


def _event_payload(
    base_payload: dict[str, str], *, ea: str, extra: dict[str, str] | None = None
) -> dict[str, str]:
    payload = dict(base_payload)
    payload.update({"t": "event", "ea": ea})
    if settings.YA_EVENT_INCLUDE_DL and settings.YA_DL:
        payload.setdefault("dl", settings.YA_DL)
    if extra:
        payload.update(extra)
    return payload


def send_pageview(cid: str) -> SendResult:
    """Send a pageview hit to Measurement Protocol."""

    prepared = _prepare_common_payload(cid)
    if isinstance(prepared, SendResult):
        return prepared
    normalized_cid, base_payload = prepared
    payload = _pageview_payload(base_payload)
    return _send_with_retry("pageview", payload, normalized_cid)


def send_trial_add(cid: str) -> SendResult:
    """Send a pageview and trial-add event via Measurement Protocol."""

    pageview_result = send_pageview(cid)
    if not pageview_result.success:
        return pageview_result

    prepared = _prepare_common_payload(cid)
    if isinstance(prepared, SendResult):
        return prepared
    normalized_cid, base_payload = prepared
    payload = _event_payload(base_payload, ea="trial-add")
    return _send_with_retry("trial-add", payload, normalized_cid)


def send_purchase(cid: str, order_id: str | None = None) -> SendResult:
    """Send a pageview and a non-ecommerce purchase event via Measurement Protocol.

    The optional ``order_id`` parameter is preserved for compatibility but is not
    transmitted to Measurement Protocol.
    """

    pageview_result = send_pageview(cid)
    if not pageview_result.success:
        return pageview_result

    prepared = _prepare_common_payload(cid)
    if isinstance(prepared, SendResult):
        return prepared
    normalized_cid, base_payload = prepared
    payload = _event_payload(base_payload, ea="purchase")
    return _send_with_retry("purchase", payload, normalized_cid)
